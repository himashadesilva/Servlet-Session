import java.io.*;
import java.util.*;

public class AddressBook {
    final  BufferedReader br;
    final  Map<String,List> contacts = new HashMap<>();
    
    /** read contacts from file and create Address Book **/
    public   AddressBook(String fileName) throws IOException{
        br = new BufferedReader(new FileReader(fileName));
        
        String line;
        while ((line = br.readLine()) != null) {
            String[] items = line.split(",");
            
			List details = Arrays.asList(items);
			details.remove(0);
            contacts.put(items[0], details);
        }
    }
    
    /** search for details of a name in the address book **/
    public List<String> search(String name){       
        return contacts.get(name);    
    }
    
    /** add details of a contact to the address book **/
    public synchronized void add(String name, List<String> details){
        contacts.put(name, details);    
    }
}
