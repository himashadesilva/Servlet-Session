import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(
    urlPatterns = {"/search", "/newEntry"},
    initParams = {@WebInitParam(name="filename", value="/addressBook.txt")}
)
public class AddressBookServlet extends HttpServlet {       
    AddressBook contacts;

    @Override
    public void init() throws ServletException {        
        ServletConfig config = getServletConfig();
        String filename = config.getInitParameter("filename");
      
         try {
            String path = config.getServletContext().getRealPath(filename);
            contacts = new AddressBook(path);
         } catch (IOException ex) {
            throw new ServletException(ex);
         }       
    }
  
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        List<String> details;
		
        if ((details = contacts.search(name)) != null) {
            response.setStatus(HttpServletResponse.SC_OK);
            PrintWriter out = response.getWriter();
            out.println(name +"  "+details);
        } else
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		String name = request.getParameter("name");
		String[] details = request.getParameter("details").split(",");

		contacts.add(name, Arrays.asList(details));

		response.setStatus(HttpServletResponse.SC_OK);
		PrintWriter out = response.getWriter();
		out.println("Added "+name +" with information "+ Arrays.toString(details));
    }
}
