import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(
        name = "newEntry",
        urlPatterns = {"/newEntry", "/search"}, //annotations
        initParams = {
            @WebInitParam(name = "filepath", value = "/addressBook.txt")}
)
public class NewEntry extends HttpServlet {

    String filename;
    String path;
    AddressBook contact;

    public void init() throws ServletException {

        contact = new AddressBook();
        ServletConfig config = getServletConfig();          //get the value of the init-parameter
        filename = config.getInitParameter("filepath");
        ServletContext sc = config.getServletContext();
        path = sc.getRealPath(filename);
        contact.initAddressBook(path);   //initialize the addressbook

    }

    protected void processRequestPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        synchronized (this) {

            String name = request.getParameter("name1");
            String details = request.getParameter("name2");
            PrintWriter out = response.getWriter();
            contact.addContact(name, details);   //add contsct to map

            if (contact.search(name) != null) {
                out.println("Contact details are successfully added..!!!");
                out.println("Added details >>>> " + contact.search(name));
            }
            if (contact.search(name) == null) {
                out.println("Process Failed...!!!");
            }
        }
    }

    protected void processRequestGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");     //process request parameters and return details of searched name
        String name = request.getParameter("name3");
        PrintWriter out = response.getWriter();
        out.println("Contact Details of " + name + " >>>> " + contact.search(name));

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequestGet(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequestPost(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    @Override
    public void destroy() {
        synchronized(this){
        contact.writeFile(path);  //write map to file
    }
    }
}
